import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, ChevronLeft, Loader2, AlertCircle, CheckCircle2, ShieldAlert, LogIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { analyzeIngredients } from '@/lib/gemini';
import { cn } from '@/lib/utils';
import { useFirebase } from '@/lib/FirebaseProvider';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from '@/components/LanguageSelector';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '@/lib/firebase';
import { signInWithPopup } from 'firebase/auth';
import { collection, addDoc, onSnapshot, query } from 'firebase/firestore';
import { Allergy } from '@/types';

export function ImageScanner() {
  const { user, isAuthReady } = useFirebase();
  const { t, i18n } = useTranslation();
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [userAllergies, setUserAllergies] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) {
      setUserAllergies([]);
      return;
    }
    const path = `users/${user.uid}/allergies`;
    const unsubscribe = onSnapshot(query(collection(db, path)), (snapshot) => {
      const names = snapshot.docs
        .map(doc => doc.data() as Allergy)
        .filter(a => a.active)
        .map(a => a.name.toLowerCase());
      setUserAllergies(names);
    });
    return () => unsubscribe();
  }, [user]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      setImage(reader.result as string);
      setIsAnalyzing(true);
      try {
        const data = await analyzeIngredients(base64, userAllergies, i18n.language);
        setResult(data);
        
        if (user) {
          const path = `users/${user.uid}/scans`;
          await addDoc(collection(db, path), {
            uid: user.uid,
            timestamp: Date.now(),
            type: 'image',
            status: data.status,
            detectedAllergens: data.detectedAllergens,
            itemName: data.itemName || 'Ingredient Scan',
            explanation: data.explanation
          });
        }
      } catch (error) {
        console.error(error);
      } finally {
        setIsAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  if (!isAuthReady) return null;

  return (
    <div className="space-y-8">
      <header className="flex items-center gap-6">
        <Link to="/" className="p-3 bg-white rounded-2xl border border-gray-100 text-gray-400 hover:text-emerald-600 hover:border-emerald-100 transition-all shadow-sm">
          <ChevronLeft size={24} />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{t('image_scanner')}</h1>
          <p className="text-gray-500 font-medium text-sm">{t('scan_labels_desc')}</p>
        </div>
        <LanguageSelector />
        {!user && (
          <button 
            onClick={handleLogin}
            className="px-6 py-2 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100"
          >
            <LogIn size={18} />
            {t('sign_in')}
          </button>
        )}
      </header>

      {!image ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border-2 border-dashed border-gray-100 rounded-[32px] p-12 text-center shadow-sm hover:border-emerald-200 transition-all group"
        >
          <div className="w-24 h-24 bg-emerald-50 rounded-3xl flex items-center justify-center text-emerald-500 mx-auto mb-8 group-hover:scale-110 transition-transform">
            <Camera size={48} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('scan_result')}</h2>
          <p className="text-gray-400 font-medium mb-10">{t('scan_labels_desc')}</p>
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef}
            onChange={handleFileChange}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="px-12 py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all flex items-center gap-3 mx-auto shadow-lg shadow-emerald-100"
          >
            <Upload size={20} />
            {t('upload_image')}
          </button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm"
          >
            <img src={image} alt="Label" className="w-full h-auto rounded-3xl object-cover" />
            <button 
              onClick={() => { setImage(null); setResult(null); }}
              className="w-full mt-6 py-4 bg-gray-50 text-gray-500 font-bold rounded-2xl hover:bg-gray-100 transition-all"
            >
              {t('scan_another')}
            </button>
          </motion.div>

          <AnimatePresence mode="wait">
            {isAnalyzing ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-white p-10 rounded-[32px] border border-gray-100 shadow-sm flex flex-col items-center justify-center text-center"
              >
                <Loader2 size={64} className="text-emerald-500 animate-spin mb-8" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4 tracking-tight">{t('analyzing')}</h3>
                <p className="text-gray-400 font-medium leading-relaxed">{t('analyzing_desc')}</p>
              </motion.div>
            ) : result ? (
              <motion.div 
                key="result"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm space-y-8"
              >
                <div className={cn(
                  "p-8 rounded-3xl flex items-center gap-6",
                  result.status === 'safe' ? "bg-emerald-50 text-emerald-700 border border-emerald-100" :
                  result.status === 'warning' ? "bg-orange-50 text-orange-700 border border-orange-100" :
                  "bg-red-50 text-red-700 border border-red-100"
                )}>
                  {result.status === 'safe' ? <CheckCircle2 size={48} /> : 
                   result.status === 'warning' ? <AlertCircle size={48} /> : 
                   <ShieldAlert size={48} />}
                  <div>
                    <h3 className="text-2xl font-bold uppercase tracking-tight">{t(result.status)}</h3>
                    <p className="font-semibold opacity-80">{result.explanation}</p>
                  </div>
                </div>

                {result.detectedAllergens.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">{t('detected_allergens')}</h4>
                    <div className="flex flex-wrap gap-3">
                      {result.detectedAllergens.map((allergen: string) => (
                        <span key={allergen} className="px-5 py-2 bg-red-100 text-red-600 rounded-full font-bold text-sm">
                          {allergen}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">{t('ingredients_found')}</h4>
                  <div className="flex flex-wrap gap-2">
                    {result.allIngredients.map((ing: string) => (
                      <span key={ing} className="px-4 py-2 bg-gray-50 text-gray-500 rounded-xl text-xs font-semibold">
                        {ing}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
