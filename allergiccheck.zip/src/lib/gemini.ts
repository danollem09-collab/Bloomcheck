import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeIngredients(base64Image: string, userAllergies: string[], language: string = 'en') {
  const model = "gemini-3-flash-preview";
  const prompt = `
    Analyze the provided ingredient label image for potential allergens.
    The user has the following allergies: ${userAllergies.join(", ")}.
    Identify if any of these allergens or their derivatives are present in the ingredients.
    Return the result in JSON format.
    IMPORTANT: Provide the explanation in the language specified: ${language}.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { text: prompt },
        { inlineData: { mimeType: "image/jpeg", data: base64Image } }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          detectedAllergens: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "List of user-specific allergens found in the label."
          },
          allIngredients: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Full list of extracted ingredients."
          },
          status: {
            type: Type.STRING,
            enum: ["safe", "warning", "danger"],
            description: "Safety status based on user allergies."
          },
          explanation: {
            type: Type.STRING,
            description: "Brief explanation of why it is safe or dangerous."
          }
        },
        required: ["detectedAllergens", "allIngredients", "status", "explanation"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}

export async function extractAllergiesFromRecord(base64Image: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `
    Extract allergy information from this medical record.
    Identify the allergen, severity, and any specific notes.
    Return the result in JSON format.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { text: prompt },
        { inlineData: { mimeType: "image/jpeg", data: base64Image } }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            severity: { type: Type.STRING, enum: ["Mild", "Moderate", "Severe", "Anaphylactic"] },
            category: { type: Type.STRING },
            notes: { type: Type.STRING }
          },
          required: ["name", "severity", "category"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
}

export async function chatWithAssistant(message: string, history: any[], userAllergies: string[], language: string = 'en') {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `
        You are AllerGuard AI, a helpful assistant for people with food allergies.
        The user has the following allergies: ${userAllergies.join(", ")}.
        Provide accurate, helpful, and empathetic advice about food safety, ingredient substitutes, and allergy management.
        Always prioritize safety. If unsure, advise the user to consult a medical professional.
        IMPORTANT: Respond in the language specified: ${language}.
      `
    }
  });

  const response = await chat.sendMessage({ message });
  return response.text;
}
