import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { AllergyHub } from './pages/AllergyHub';
import { ImageScanner } from './pages/ImageScanner';
import { QRScanner } from './pages/QRScanner';
import { MedicalRecords } from './pages/MedicalRecords';
import { AIChat } from './pages/AIChat';
import { FirebaseProvider } from './lib/FirebaseProvider';
import { ErrorBoundary } from './components/ErrorBoundary';
import { WelcomeScreen } from './components/WelcomeScreen';
import { AuthScreen } from './components/AuthScreen';
import { useFirebase } from './lib/FirebaseProvider';

function AppContent() {
  const [showWelcome, setShowWelcome] = useState(false);
  const { user, isAuthReady } = useFirebase();

  // Reset welcome screen flag when user signs in for the first time in this session
  useEffect(() => {
    if (user) {
      const hasSeenWelcome = sessionStorage.getItem('hasSeenWelcome_v2');
      if (!hasSeenWelcome) {
        setShowWelcome(true);
      }
    }
  }, [user]);

  const handleWelcomeComplete = () => {
    setShowWelcome(false);
    sessionStorage.setItem('hasSeenWelcome_v2', 'true');
  };

  if (!isAuthReady) return null;

  return (
    <>
      {!user ? (
        <AuthScreen />
      ) : showWelcome ? (
        <WelcomeScreen onComplete={handleWelcomeComplete} />
      ) : (
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="hub" element={<AllergyHub />} />
              <Route path="image" element={<ImageScanner />} />
              <Route path="qr" element={<QRScanner />} />
              <Route path="records" element={<MedicalRecords />} />
              <Route path="chat" element={<AIChat />} />
            </Route>
          </Routes>
        </BrowserRouter>
      )}
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <FirebaseProvider>
        <AppContent />
      </FirebaseProvider>
    </ErrorBoundary>
  );
}
