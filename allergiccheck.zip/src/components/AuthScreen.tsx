import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, LogIn, Mail, ArrowRight, CheckCircle2 } from 'lucide-react';
import { auth, googleProvider } from '@/lib/firebase';
import { signInWithPopup, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from './LanguageSelector';

export function AuthScreen() {
  const { t } = useTranslation();
  const [isRegistering, setIsRegistering] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError(err.message || 'Failed to sign in with Google');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      if (isRegistering) {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] bg-gray-50 flex items-center justify-center p-6 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-[40px] shadow-2xl shadow-emerald-900/5 border border-gray-100 p-10 space-y-8"
      >
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 mx-auto border border-emerald-100 shadow-sm">
            <Shield size={32} />
          </div>
          <div className="flex justify-center mb-4">
            <LanguageSelector />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
            {isRegistering ? t('create_account') : t('welcome_back')}
          </h1>
          <p className="text-gray-400 font-medium">
            {isRegistering 
              ? t('register_desc') 
              : t('login_desc')}
          </p>
        </div>

        {error && (
          <div className="p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-medium text-center">
            {error}
          </div>
        )}

        <div className="space-y-6">
          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full py-4 bg-white border-2 border-gray-100 rounded-2xl flex items-center justify-center gap-3 font-bold text-gray-700 hover:border-emerald-200 hover:bg-emerald-50 transition-all group disabled:opacity-50"
          >
            <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
            {isRegistering ? t('register_google') : t('login_google')}
          </button>

          <div className="relative flex items-center gap-4">
            <div className="flex-1 h-px bg-gray-100" />
            <span className="text-xs font-bold text-gray-300 uppercase tracking-widest">{t('or_email')}</span>
            <div className="flex-1 h-px bg-gray-100" />
          </div>

          <form onSubmit={handleEmailAuth} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">{t('email_address')}</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-emerald-500 transition-colors" size={20} />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all font-medium"
                  placeholder="name@example.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">{t('password')}</label>
              <div className="relative group">
                <LogIn className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-emerald-500 transition-colors" size={20} />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all font-medium"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-emerald-600 text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all disabled:opacity-50 mt-4"
            >
              {loading ? t('processing') : isRegistering ? t('create_account') : t('sign_in')}
              {!loading && <ArrowRight size={20} />}
            </button>
          </form>
        </div>

        <div className="text-center">
          <button
            onClick={() => setIsRegistering(!isRegistering)}
            className="text-sm font-bold text-gray-400 hover:text-emerald-600 transition-colors"
          >
            {isRegistering 
              ? t('already_account') 
              : t('no_account')}
          </button>
        </div>

        <div className="pt-4 flex items-center justify-center gap-6 opacity-40 grayscale">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={14} />
            <span className="text-[10px] font-bold uppercase tracking-wider">{t('secure_data')}</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 size={14} />
            <span className="text-[10px] font-bold uppercase tracking-wider">{t('privacy_first')}</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
