import React, { useState, useRef, useEffect } from 'react';
import { QrCode, Camera, ChevronLeft, Loader2, AlertCircle, CheckCircle2, ShieldAlert, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Html5Qrcode } from 'html5-qrcode';
import { auth, db } from '@/lib/firebase';
import { collection, addDoc } from 'firebase/firestore';

export function QRScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerId = "qr-reader";

  useEffect(() => {
    return () => {
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().catch(console.error);
      }
    };
  }, []);

  const startCamera = async () => {
    setIsCameraActive(true);
    setError(null);
    
    // Wait for the DOM element to be available and ensure it's the only one with this ID
    setTimeout(async () => {
      try {
        const element = document.getElementById(scannerId);
        if (!element) {
          throw new Error("Scanner element not found");
        }

        const html5QrCode = new Html5Qrcode(scannerId);
        scannerRef.current = html5QrCode;
        
        const config = { 
          fps: 10, 
          qrbox: { width: 250, height: 250 },
          aspectRatio: 1.777778 // 16:9
        };
        
        await html5QrCode.start(
          { facingMode: "environment" },
          config,
          (decodedText) => {
            handleScanSuccess(decodedText);
          },
          () => {
            // Silent failure for each frame that doesn't have a QR code
          }
        );
      } catch (err) {
        console.error("Failed to start scanner:", err);
        setError("Could not access camera. Please ensure you've granted permission and are using a secure connection (HTTPS).");
        setIsCameraActive(false);
      }
    }, 300); // Increased timeout to ensure DOM is ready
  };

  const stopCamera = async () => {
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.stop();
        scannerRef.current = null;
        setIsCameraActive(false);
      } catch (err) {
        console.error("Failed to stop scanner:", err);
        setIsCameraActive(false);
      }
    } else {
      setIsCameraActive(false);
    }
  };

  const handleScanSuccess = async (decodedText: string) => {
    stopCamera();
    setIsScanning(true);
    
    // In a real app, we'd fetch product data based on the QR/Barcode text
    // For now, we'll mock a successful scan after a delay
    setTimeout(async () => {
      const scanData = {
        status: 'safe' as const,
        itemName: decodedText.length > 20 ? 'Scanned Product' : decodedText,
        detectedAllergens: [],
        explanation: 'This product does not contain any of your tracked allergens based on the scanned data.'
      };
      
      setResult(scanData);
      setIsScanning(false);

      // Save to Firestore if user is logged in
      const user = auth.currentUser;
      if (user) {
        try {
          const path = `users/${user.uid}/scans`;
          await addDoc(collection(db, path), {
            uid: user.uid,
            timestamp: Date.now(),
            type: 'qr',
            status: scanData.status,
            detectedAllergens: scanData.detectedAllergens,
            itemName: scanData.itemName,
            explanation: scanData.explanation
          });
        } catch (error) {
          console.error("Failed to save scan:", error);
          // We don't use handleFirestoreError here to avoid crashing the UI for a background save
        }
      }
    }, 1500);
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center gap-6">
        <Link to="/" className="p-3 bg-white rounded-2xl border border-gray-100 text-gray-400 hover:text-emerald-600 hover:border-emerald-100 transition-all shadow-sm">
          <ChevronLeft size={24} />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">QR / Barcode Scanner</h1>
          <p className="text-gray-500 font-medium text-sm">Scan product barcodes or QR codes</p>
        </div>
      </header>

      {error && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-6 bg-red-50 border border-red-100 rounded-[32px] flex flex-col items-center text-center gap-4 text-red-600 shadow-sm"
        >
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <AlertCircle size={24} />
          </div>
          <div>
            <h3 className="font-bold text-lg">Camera Error</h3>
            <p className="text-sm opacity-90 max-w-md mx-auto">{error}</p>
          </div>
          <button 
            onClick={() => setError(null)}
            className="px-6 py-2 bg-red-600 text-white rounded-xl font-bold text-sm hover:bg-red-700 transition-colors"
          >
            Dismiss
          </button>
        </motion.div>
      )}

      {!result && !isScanning && !isCameraActive ? (
        <div className="max-w-xl mx-auto">
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={startCamera}
            className="w-full bg-white p-12 rounded-[32px] border border-gray-100 flex flex-col items-center gap-6 text-center shadow-sm hover:border-emerald-200 transition-all group"
          >
            <div className="w-24 h-24 bg-emerald-50 rounded-[32px] flex items-center justify-center text-emerald-500 group-hover:scale-110 transition-transform shadow-inner">
              <Camera size={48} />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Start Scanning</h3>
              <p className="text-gray-400 font-medium max-w-xs">Point your camera at any QR code or barcode to instantly check for allergens.</p>
            </div>
            <div className="px-8 py-3 bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-100 group-hover:bg-emerald-700 transition-colors">
              Open Camera
            </div>
          </motion.button>
        </div>
      ) : isCameraActive ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative bg-black rounded-[32px] overflow-hidden shadow-2xl aspect-[4/3] md:aspect-video max-w-5xl mx-auto border-8 border-white"
        >
          <div id={scannerId} className="w-full h-full [&>video]:object-cover" />
          
          {/* Scanning Overlay */}
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
            {/* Bounding Box */}
            <div className="w-64 h-64 md:w-80 md:h-80 border-2 border-emerald-500/30 rounded-[32px] relative">
              {/* Animated Corners */}
              <div className="absolute -top-2 -left-2 w-12 h-12 border-t-4 border-l-4 border-emerald-500 rounded-tl-2xl" />
              <div className="absolute -top-2 -right-2 w-12 h-12 border-t-4 border-r-4 border-emerald-500 rounded-tr-2xl" />
              <div className="absolute -bottom-2 -left-2 w-12 h-12 border-b-4 border-l-4 border-emerald-500 rounded-bl-2xl" />
              <div className="absolute -bottom-2 -right-2 w-12 h-12 border-b-4 border-r-4 border-emerald-500 rounded-br-2xl" />
              
              {/* Scanning Line */}
              <motion.div 
                animate={{ top: ['5%', '95%', '5%'] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute left-4 right-4 h-1 bg-emerald-400 shadow-[0_0_20px_rgba(52,211,153,0.8)] rounded-full z-10"
              />
              
              {/* Inner Pulse */}
              <motion.div 
                animate={{ opacity: [0.1, 0.3, 0.1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 bg-emerald-500/10 rounded-[32px]"
              />
            </div>

            {/* Status Indicator */}
            <div className="mt-10 flex flex-col items-center gap-4">
              <div className="flex items-center gap-3 bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10">
                <Loader2 size={20} className="text-emerald-400 animate-spin" />
                <span className="text-white font-bold tracking-wide uppercase text-sm">Scanning for codes...</span>
              </div>
              <p className="text-white/70 font-medium text-sm">Align code within the frame</p>
            </div>
          </div>

          {/* Controls */}
          <div className="absolute bottom-8 left-0 right-0 flex justify-center px-8">
            <button 
              onClick={stopCamera}
              className="px-8 py-4 bg-white/10 hover:bg-red-500/20 backdrop-blur-md text-white font-bold rounded-2xl border border-white/20 transition-all flex items-center gap-3 hover:border-red-500/50 group"
            >
              <XCircle size={20} className="group-hover:text-red-400 transition-colors" />
              Stop Scanning
            </button>
          </div>
        </motion.div>
      ) : (
        <AnimatePresence mode="wait">
          {isScanning ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white p-12 rounded-[32px] border border-gray-100 shadow-sm flex flex-col items-center justify-center text-center"
            >
              <div className="relative mb-10">
                <QrCode size={80} className="text-emerald-500 animate-pulse" />
                <div className="absolute inset-0 border-4 border-emerald-500 rounded-2xl animate-ping opacity-20" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 tracking-tight">Processing Code...</h3>
              <p className="text-gray-400 font-medium leading-relaxed max-w-md">We're looking up the product data and checking it against your allergy profile.</p>
            </motion.div>
          ) : result ? (
            <motion.div 
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-10 rounded-[32px] border border-gray-100 shadow-sm space-y-10 max-w-3xl mx-auto"
            >
              <div className={cn(
                "p-10 rounded-[32px] flex items-center gap-8",
                result.status === 'safe' ? "bg-emerald-50 text-emerald-700 border border-emerald-100" :
                result.status === 'warning' ? "bg-orange-50 text-orange-700 border border-orange-100" :
                "bg-red-50 text-red-700 border border-red-100"
              )}>
                {result.status === 'safe' ? <CheckCircle2 size={64} /> : 
                 result.status === 'warning' ? <AlertCircle size={64} /> : 
                 <ShieldAlert size={64} />}
                <div>
                  <h3 className="text-3xl font-bold uppercase tracking-tight mb-2">{result.status} Item</h3>
                  <p className="text-xl font-bold opacity-90">{result.itemName}</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="p-8 bg-gray-50 rounded-3xl border border-gray-100">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Safety Analysis</h4>
                  <p className="text-gray-700 font-semibold text-lg leading-relaxed">{result.explanation}</p>
                </div>

                {result.detectedAllergens.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Detected Allergens</h4>
                    <div className="flex flex-wrap gap-3">
                      {result.detectedAllergens.map((allergen: string) => (
                        <span key={allergen} className="px-6 py-3 bg-red-100 text-red-600 rounded-2xl font-bold text-lg">
                          {allergen}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <button 
                onClick={() => { setResult(null); }}
                className="w-full py-5 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 text-lg"
              >
                Scan Another Product
              </button>
            </motion.div>
          ) : null}
        </AnimatePresence>
      )}
      {/* Hidden element for camera scanning */}
      <div id={scannerId} className="hidden" />
    </div>
  );

}
