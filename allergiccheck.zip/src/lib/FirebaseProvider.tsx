import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './firebase';
import { motion, AnimatePresence } from 'motion/react';
import { WifiOff } from 'lucide-react';

interface FirebaseContextType {
  user: User | null;
  isAuthReady: boolean;
  isOnline: boolean;
}

const FirebaseContext = createContext<FirebaseContextType>({ 
  user: null, 
  isAuthReady: false,
  isOnline: true 
});

export const useFirebase = () => useContext(FirebaseContext);

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setIsAuthReady(true);
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribe();
    };
  }, []);

  return (
    <FirebaseContext.Provider value={{ user, isAuthReady, isOnline }}>
      {children}
      <AnimatePresence>
        {!isOnline && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 bg-gray-900 text-white rounded-full shadow-2xl flex items-center gap-3 border border-white/10 backdrop-blur-md"
          >
            <WifiOff size={18} className="text-orange-400" />
            <span className="text-sm font-bold tracking-tight">Offline Mode</span>
            <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse" />
          </motion.div>
        )}
      </AnimatePresence>
    </FirebaseContext.Provider>
  );
}
