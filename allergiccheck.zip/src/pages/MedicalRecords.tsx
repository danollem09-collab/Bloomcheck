import React, { useState, useRef } from 'react';
import { ClipboardList, Upload, ChevronLeft, Loader2, CheckCircle2, ShieldCheck, FileText, LogIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { extractAllergiesFromRecord } from '@/lib/gemini';
import { cn } from '@/lib/utils';
import { useFirebase } from '@/lib/FirebaseProvider';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '@/lib/firebase';
import { signInWithPopup } from 'firebase/auth';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export function MedicalRecords() {
  const { user, isAuthReady } = useFirebase();
  const [file, setFile] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [extractedAllergies, setExtractedAllergies] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      setFile(reader.result as string);
      setIsAnalyzing(true);
      try {
        const data = await extractAllergiesFromRecord(base64);
        setExtractedAllergies(data);
      } catch (error) {
        console.error(error);
      } finally {
        setIsAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const addAllToHub = async () => {
    if (!user) return;
    const path = `users/${user.uid}/allergies`;
    try {
      await Promise.all(extractedAllergies.map(allergy => 
        addDoc(collection(db, path), {
          ...allergy,
          uid: user.uid,
          active: true,
          createdAt: serverTimestamp()
        })
      ));
      setExtractedAllergies([]);
      setFile(null);
      alert("Allergies added to your hub!");
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  if (!isAuthReady) return null;

  return (
    <div className="space-y-8">
      <header className="flex items-center gap-6">
        <Link to="/" className="p-3 bg-white rounded-2xl border border-gray-100 text-gray-400 hover:text-emerald-600 hover:border-emerald-100 transition-all shadow-sm">
          <ChevronLeft size={24} />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Registration Scan</h1>
          <p className="text-gray-500 font-medium text-sm">Import medical records securely</p>
        </div>
        {!user && (
          <button 
            onClick={handleLogin}
            className="px-6 py-2 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100"
          >
            <LogIn size={18} />
            Sign In
          </button>
        )}
      </header>

      <div className="bg-emerald-50 p-8 rounded-[32px] border border-emerald-100 flex items-center gap-6 shadow-sm">
        <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm shrink-0">
          <ShieldCheck size={32} />
        </div>
        <p className="text-emerald-700 font-semibold leading-relaxed">Your documents are processed securely and never stored. Only extracted allergy data is saved to your profile.</p>
      </div>

      {!file ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border-2 border-dashed border-gray-100 rounded-[32px] p-12 text-center shadow-sm hover:border-emerald-200 transition-all group"
        >
          <div className="w-24 h-24 bg-emerald-50 rounded-3xl flex items-center justify-center text-emerald-500 mx-auto mb-8 group-hover:scale-110 transition-transform">
            <Upload size={48} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Upload Medical Records</h2>
          <p className="text-gray-400 font-medium mb-10">PDF, images, or documents with allergy test results</p>
          <input 
            type="file" 
            accept="image/*,application/pdf" 
            className="hidden" 
            ref={fileInputRef}
            onChange={handleFileChange}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="px-12 py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all flex items-center gap-3 mx-auto shadow-lg shadow-emerald-100"
          >
            <FileText size={20} />
            Choose File
          </button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm"
          >
            <div className="aspect-[3/4] bg-gray-50 rounded-3xl flex items-center justify-center overflow-hidden">
              {file.startsWith('data:image') ? (
                <img src={file} alt="Record" className="w-full h-full object-contain" />
              ) : (
                <div className="text-center space-y-4">
                  <FileText size={64} className="text-gray-300 mx-auto" />
                  <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">PDF Document Loaded</p>
                </div>
              )}
            </div>
            <button 
              onClick={() => { setFile(null); setExtractedAllergies([]); }}
              className="w-full mt-6 py-4 bg-gray-50 text-gray-500 font-bold rounded-2xl hover:bg-gray-100 transition-all"
            >
              Upload Another File
            </button>
          </motion.div>

          <AnimatePresence mode="wait">
            {isAnalyzing ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-white p-10 rounded-[32px] border border-gray-100 shadow-sm flex flex-col items-center justify-center text-center"
              >
                <Loader2 size={64} className="text-emerald-500 animate-spin mb-8" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4 tracking-tight">Extracting Data...</h3>
                <p className="text-gray-400 font-medium leading-relaxed">Our AI is reading your medical records to identify confirmed allergies. This will just take a moment.</p>
              </motion.div>
            ) : extractedAllergies.length > 0 ? (
              <motion.div 
                key="result"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm space-y-8"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900 tracking-tight">Extracted Allergies</h3>
                  <span className="px-4 py-2 bg-emerald-100 text-emerald-600 rounded-xl font-bold text-sm">
                    {extractedAllergies.length} Found
                  </span>
                </div>

                <div className="space-y-4">
                  {extractedAllergies.map((allergy, idx) => (
                    <div key={idx} className="p-6 bg-gray-50 rounded-3xl border border-gray-100 flex items-center gap-6 group hover:border-emerald-200 transition-all">
                      <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-emerald-500 shadow-sm">
                        <ShieldCheck size={24} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <p className="font-bold text-gray-900 text-lg">{allergy.name}</p>
                          <span className="px-3 py-1 bg-red-100 text-red-600 rounded-full text-[10px] font-bold uppercase tracking-wider">
                            {allergy.severity}
                          </span>
                        </div>
                        <p className="text-gray-400 font-medium text-sm">{allergy.category}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={addAllToHub}
                  disabled={!user}
                  className="w-full py-5 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  <CheckCircle2 size={24} />
                  {user ? 'Add All to Hub' : 'Sign in to add to hub'}
                </button>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
