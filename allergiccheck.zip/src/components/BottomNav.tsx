import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'motion/react';
import { Home, ClipboardList, Camera, QrCode, MessageCircle, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const navItems = [
  { icon: Home, labelKey: 'dashboard', path: '/' },
  { icon: ClipboardList, labelKey: 'records', path: '/records' },
  { icon: Camera, labelKey: 'image_scanner', path: '/image' },
  { icon: QrCode, labelKey: 'qr_scanner', path: '/qr' },
  { icon: MessageCircle, labelKey: 'chat', path: '/chat' },
  { icon: Shield, labelKey: 'hub', path: '/hub' },
];

export function BottomNav() {
  const { t } = useTranslation();
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 py-2 px-4 z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.03)]">
      <nav className="max-w-md mx-auto flex items-center justify-between">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                "flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all duration-200 group relative",
                isActive
                  ? "text-emerald-600"
                  : "text-gray-400 hover:text-gray-600"
              )
            }
          >
            {({ isActive }) => (
              <>
                <item.icon size={22} className={cn("shrink-0 transition-transform group-hover:scale-110", isActive && "scale-110")} />
                <span className="text-[10px] font-bold tracking-tight">{t(item.labelKey)}</span>
                {isActive && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute -top-2 left-1/2 -translate-x-1/2 w-1 h-1 bg-emerald-500 rounded-full"
                  />
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
