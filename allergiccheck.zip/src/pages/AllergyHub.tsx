import React, { useState, useEffect } from 'react';
import { Shield, Plus, Search, Filter, Trash2, ToggleLeft, ToggleRight, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { Allergy, AllergySeverity } from '@/types';
import { cn } from '@/lib/utils';
import { useFirebase } from '@/lib/FirebaseProvider';
import { db, handleFirestoreError, OperationType } from '@/lib/firebase';
import { collection, onSnapshot, query, addDoc, updateDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';

export function AllergyHub() {
  const { user, isAuthReady } = useFirebase();
  const [allergies, setAllergies] = useState<Allergy[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAllergy, setNewAllergy] = useState({
    name: '',
    category: 'Food',
    severity: 'Mild' as AllergySeverity,
    notes: ''
  });

  useEffect(() => {
    if (!user) {
      setAllergies([]);
      return;
    }

    const path = `users/${user.uid}/allergies`;
    const q = query(collection(db, path));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Allergy[];
      setAllergies(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return () => unsubscribe();
  }, [user]);

  const toggleActive = async (allergy: Allergy) => {
    if (!user) return;
    const path = `users/${user.uid}/allergies`;
    try {
      await updateDoc(doc(db, path, allergy.id), { active: !allergy.active });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${path}/${allergy.id}`);
    }
  };

  const deleteAllergy = async (id: string) => {
    if (!user) return;
    const path = `users/${user.uid}/allergies`;
    try {
      await deleteDoc(doc(db, path, id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${path}/${id}`);
    }
  };

  const saveAllergy = async () => {
    if (!user || !newAllergy.name.trim()) return;
    const path = `users/${user.uid}/allergies`;
    try {
      await addDoc(collection(db, path), {
        ...newAllergy,
        uid: user.uid,
        active: true,
        createdAt: serverTimestamp()
      });
      setShowAddModal(false);
      setNewAllergy({ name: '', category: 'Food', severity: 'Mild', notes: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  };

  const filteredAllergies = allergies.filter(a => 
    a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isAuthReady || !user) return null;

  return (
    <div className="space-y-8">
      <header className="flex items-center gap-6">
        <Link to="/" className="p-3 bg-white rounded-2xl border border-gray-100 text-gray-400 hover:text-emerald-600 hover:border-emerald-100 transition-all shadow-sm">
          <ChevronLeft size={24} />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Allergy Hub</h1>
          <p className="text-gray-500 font-medium text-sm">{allergies.filter(a => a.active).length} active of {allergies.length} total</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="px-8 py-3 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100"
        >
          <Plus size={20} />
          Add
        </button>
      </header>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-emerald-500 transition-colors" size={20} />
          <input 
            type="text" 
            placeholder="Search allergies..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-4 bg-white border border-gray-100 rounded-3xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-sm"
          />
        </div>
        <div className="flex gap-2">
          <button className="p-4 bg-white border border-gray-100 rounded-3xl text-gray-400 hover:text-emerald-600 hover:border-emerald-100 transition-all shadow-sm">
            <Filter size={20} />
          </button>
          <select className="px-6 py-4 bg-white border border-gray-100 rounded-3xl text-gray-600 font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-sm appearance-none">
            <option>All</option>
            <option>Food</option>
            <option>Medicine</option>
            <option>Environmental</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <AnimatePresence mode="popLayout">
          {filteredAllergies.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white p-12 rounded-[32px] border border-gray-100 text-center shadow-sm"
            >
              <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-6">
                <Shield size={40} />
              </div>
              <p className="text-gray-400 font-medium text-lg">No allergies found matching your search.</p>
            </motion.div>
          ) : (
            filteredAllergies.map((allergy) => (
              <motion.div
                key={allergy.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={cn(
                  "bg-white p-8 rounded-3xl border border-gray-100 flex items-center gap-6 shadow-sm group hover:shadow-md transition-all",
                  !allergy.active && "opacity-60 grayscale"
                )}
              >
                <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-400 group-hover:text-emerald-500 group-hover:bg-emerald-50 transition-colors">
                  <Shield size={32} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-xl font-bold text-gray-900">{allergy.name}</h3>
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                      allergy.severity === 'Anaphylactic' ? "bg-red-100 text-red-600" :
                      allergy.severity === 'Severe' ? "bg-orange-100 text-orange-600" :
                      "bg-blue-100 text-blue-600"
                    )}>
                      {allergy.severity}
                    </span>
                  </div>
                  <p className="text-gray-400 font-medium text-sm">{allergy.category}</p>
                  {allergy.notes && <p className="text-gray-500 mt-2 text-sm italic">"{allergy.notes}"</p>}
                </div>
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => toggleActive(allergy)}
                    className={cn(
                      "transition-colors",
                      allergy.active ? "text-emerald-500" : "text-gray-300"
                    )}
                  >
                    {allergy.active ? <ToggleRight size={40} /> : <ToggleLeft size={40} />}
                  </button>
                  <button 
                    onClick={() => deleteAllergy(allergy.id)}
                    className="p-3 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white w-full max-w-lg rounded-[32px] p-8 shadow-2xl"
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Add New Allergy</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Allergen Name</label>
                <input 
                  type="text" 
                  value={newAllergy.name}
                  onChange={(e) => setNewAllergy({ ...newAllergy, name: e.target.value })}
                  className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all font-medium" 
                  placeholder="e.g. Peanut, Penicillin" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Category</label>
                  <select 
                    value={newAllergy.category}
                    onChange={(e) => setNewAllergy({ ...newAllergy, category: e.target.value })}
                    className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all font-medium appearance-none"
                  >
                    <option>Food</option>
                    <option>Medicine</option>
                    <option>Environmental</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Severity</label>
                  <select 
                    value={newAllergy.severity}
                    onChange={(e) => setNewAllergy({ ...newAllergy, severity: e.target.value as AllergySeverity })}
                    className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all font-medium appearance-none"
                  >
                    <option>Mild</option>
                    <option>Moderate</option>
                    <option>Severe</option>
                    <option>Anaphylactic</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Notes</label>
                <textarea 
                  value={newAllergy.notes}
                  onChange={(e) => setNewAllergy({ ...newAllergy, notes: e.target.value })}
                  className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all font-medium h-32 resize-none" 
                  placeholder="Add any specific details..."
                ></textarea>
              </div>
              <div className="flex gap-4 pt-4">
                <button onClick={() => setShowAddModal(false)} className="flex-1 py-4 bg-gray-100 text-gray-500 font-bold rounded-2xl hover:bg-gray-200 transition-all">Cancel</button>
                <button onClick={saveAllergy} className="flex-1 py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100">Save Allergy</button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
