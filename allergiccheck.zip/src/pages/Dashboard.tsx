import React, { useState, useEffect } from 'react';
import { Shield, ClipboardList, Camera, QrCode, MessageCircle, ArrowRight, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { useFirebase } from '@/lib/FirebaseProvider';
import { auth, db, handleFirestoreError, OperationType } from '@/lib/firebase';
import { signOut } from 'firebase/auth';
import { collection, onSnapshot, query, limit, orderBy } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { Allergy, ScanResult } from '@/types';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from '@/components/LanguageSelector';

export function Dashboard() {
  const { user, isAuthReady } = useFirebase();
  const { t } = useTranslation();

  const quickActions = [
    { icon: ClipboardList, label: t('import_records'), sub: t('import_records_desc'), path: '/records', color: 'bg-emerald-100 text-emerald-600' },
    { icon: Camera, label: t('image_scanner'), sub: t('image_scanner_desc'), path: '/image', color: 'bg-orange-100 text-orange-600' },
    { icon: QrCode, label: t('qr_scanner'), sub: t('qr_scanner_desc'), path: '/qr', color: 'bg-blue-100 text-blue-600' },
    { icon: MessageCircle, label: t('ai_assistant'), sub: t('ai_assistant_desc'), path: '/chat', color: 'bg-cyan-100 text-cyan-600' },
    { icon: Shield, label: t('hub'), sub: t('allergy_hub_desc'), path: '/hub', color: 'bg-purple-100 text-purple-600' },
  ];

  const [allergies, setAllergies] = useState<Allergy[]>([]);
  const [scans, setScans] = useState<ScanResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setAllergies([]);
      setScans([]);
      setLoading(false);
      return;
    }

    const allergiesPath = `users/${user.uid}/allergies`;
    const scansPath = `users/${user.uid}/scans`;

    const allergiesQuery = query(collection(db, allergiesPath));
    const scansQuery = query(collection(db, scansPath), orderBy('timestamp', 'desc'), limit(10));

    const unsubAllergies = onSnapshot(allergiesQuery, (snapshot) => {
      setAllergies(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Allergy[]);
    }, (error) => handleFirestoreError(error, OperationType.LIST, allergiesPath));

    const unsubScans = onSnapshot(scansQuery, (snapshot) => {
      setScans(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as ScanResult[]);
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.LIST, scansPath));

    return () => {
      unsubAllergies();
      unsubScans();
    };
  }, [user]);

  const activeAllergies = allergies.filter(a => a.active);
  const safeScans = scans.filter(s => s.status === 'safe');

  const stats = [
    { label: t('active_allergies'), value: activeAllergies.length, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: t('recent_scans'), value: scans.length, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: t('safe_items'), value: safeScans.length, color: 'text-blue-600', bg: 'bg-blue-50' },
  ];

  if (!isAuthReady) return null;

  return (
    <div className="space-y-10 pb-10">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 border border-emerald-100">
            <Shield size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{t('allergy_center')}</h1>
            <p className="text-gray-500 font-medium text-sm">{t('experts')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <LanguageSelector />
          <button 
            onClick={() => signOut(auth)}
            className="p-3 bg-white border border-gray-100 rounded-2xl text-gray-400 hover:text-red-500 hover:border-red-100 transition-all shadow-sm"
            title={t('sign_out')}
          >
            <LogOut size={20} />
          </button>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
          >
            <p className={`text-4xl font-bold ${stat.color} mb-1`}>{stat.value}</p>
            <p className="text-gray-500 font-semibold uppercase text-[10px] tracking-widest">{stat.label}</p>
          </motion.div>
        ))}
      </section>

      <section className="space-y-6">
        <h2 className="text-xl font-bold text-gray-800 uppercase tracking-wider">{t('quick_actions')}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickActions.map((action, idx) => (
            <Link key={action.label} to={action.path}>
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-white p-6 rounded-3xl border border-gray-100 flex items-center gap-5 group hover:border-emerald-200 transition-colors shadow-sm"
              >
                <div className={`w-14 h-14 rounded-2xl ${action.color} flex items-center justify-center shrink-0 transition-transform group-hover:rotate-6`}>
                  <action.icon size={28} />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-gray-900 text-lg">{action.label}</p>
                  <p className="text-gray-400 text-sm font-medium">{action.sub}</p>
                </div>
                <ArrowRight className="text-gray-300 group-hover:text-emerald-500 transition-colors" size={20} />
              </motion.div>
            </Link>
          ))}
        </div>
      </section>

      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-800 uppercase tracking-wider">{t('your_allergies')}</h2>
          <Link to="/hub" className="text-emerald-600 font-bold text-sm hover:underline">{t('view_all')}</Link>
        </div>
        {activeAllergies.length === 0 ? (
          <div className="bg-white p-10 rounded-3xl border border-gray-100 text-center shadow-sm">
            <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-6">
              <Shield size={40} />
            </div>
            <p className="text-gray-400 font-medium text-lg">{t('no_allergies')}</p>
            <Link to="/hub" className="inline-block mt-6 px-8 py-3 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-100">
              {t('add_first_allergy')}
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeAllergies.slice(0, 3).map((allergy) => (
              <div key={allergy.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
                  <Shield size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900">{allergy.name}</p>
                  <p className="text-gray-400 text-xs font-bold uppercase tracking-widest">{allergy.severity}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {scans.length > 0 && (
        <section className="space-y-6">
          <h2 className="text-xl font-bold text-gray-800 uppercase tracking-wider">{t('recent_scans')}</h2>
          <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm">
            {scans.map((scan, idx) => (
              <div key={scan.id} className={cn(
                "p-6 flex items-center justify-between transition-colors hover:bg-gray-50",
                idx !== scans.length - 1 && "border-bottom border-gray-100"
              )}>
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center",
                    scan.status === 'safe' ? "bg-emerald-100 text-emerald-600" :
                    scan.status === 'warning' ? "bg-orange-100 text-orange-600" :
                    "bg-red-100 text-red-600"
                  )}>
                    {scan.type === 'image' ? <Camera size={20} /> : <QrCode size={20} />}
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">{scan.itemName || t('unnamed_scan')}</p>
                    <p className="text-gray-400 text-xs font-medium">{new Date(scan.timestamp).toLocaleDateString()}</p>
                  </div>
                </div>
                <span className={cn(
                  "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                  scan.status === 'safe' ? "bg-emerald-50 text-emerald-600" :
                  scan.status === 'warning' ? "bg-orange-50 text-orange-600" :
                  "bg-red-50 text-red-600"
                )}>
                  {t(scan.status)}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
