import React from 'react';
import { BottomNav } from './BottomNav';
import { Outlet } from 'react-router-dom';

export function Layout() {
  return (
    <div className="min-h-screen bg-gray-50 font-sans flex flex-col">
      <main className="flex-1 overflow-y-auto p-4 lg:p-8 pb-24 lg:pb-24">
        <div className="max-w-6xl mx-auto">
          <Outlet />
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
