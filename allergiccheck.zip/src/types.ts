export type AllergySeverity = 'Mild' | 'Moderate' | 'Severe' | 'Anaphylactic';

export interface Allergy {
  id: string;
  name: string;
  category: string;
  severity: AllergySeverity;
  notes?: string;
  active: boolean;
}

export interface ScanResult {
  id: string;
  timestamp: number;
  type: 'image' | 'qr' | 'record';
  status: 'safe' | 'warning' | 'danger';
  detectedAllergens: string[];
  itemName?: string;
}
