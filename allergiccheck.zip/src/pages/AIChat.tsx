import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, ChevronLeft, Loader2, ShieldCheck, User, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { chatWithAssistant } from '@/lib/gemini';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from '@/components/LanguageSelector';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export function AIChat() {
  const { t, i18n } = useTranslation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions = [
    t('q1'),
    t('q2'),
    t('q3'),
    t('q4'),
  ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await chatWithAssistant(text, messages, ['peanut', 'shellfish'], i18n.language);
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response || "I'm sorry, I couldn't process that request.",
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col space-y-8">
      <header className="flex items-center gap-6">
        <Link to="/" className="p-3 bg-white rounded-2xl border border-gray-100 text-gray-400 hover:text-emerald-600 hover:border-emerald-100 transition-all shadow-sm">
          <ChevronLeft size={24} />
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 border border-emerald-100">
              <Bot size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{t('ai_assistant') || 'AI Assistant'}</h1>
              <p className="text-gray-500 font-medium text-sm">{t('chat_desc') || 'Ask me about food safety'}</p>
            </div>
          </div>
        </div>
        <LanguageSelector />
      </header>

      <div className="flex-1 overflow-y-auto px-4 space-y-8 scroll-smooth" ref={scrollRef}>
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-10">
            <div className="w-20 h-20 bg-emerald-50 rounded-[32px] flex items-center justify-center text-emerald-500 animate-pulse">
              <MessageCircle size={40} />
            </div>
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-gray-900 tracking-tight">{t('how_can_i_help') || 'How can I help?'}</h2>
              <p className="text-gray-400 font-medium max-w-md leading-relaxed text-sm">{t('chat_desc') || 'Ask me about food safety, ingredient substitutes, or anything allergy-related.'}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
              {suggestedQuestions.map((q) => (
                <button 
                  key={q}
                  onClick={() => handleSend(q)}
                  className="p-5 bg-white border border-gray-100 rounded-2xl text-left hover:border-emerald-200 hover:bg-emerald-50/30 transition-all shadow-sm group"
                >
                  <p className="text-gray-600 font-semibold text-xs group-hover:text-emerald-700">{q}</p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            {messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "flex gap-4 max-w-3xl",
                  msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm",
                  msg.role === 'user' ? "bg-emerald-600 text-white" : "bg-white text-emerald-600 border border-emerald-100"
                )}>
                  {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
                </div>
                <div className={cn(
                  "p-5 rounded-2xl shadow-sm leading-relaxed font-medium text-sm",
                  msg.role === 'user' ? "bg-emerald-600 text-white" : "bg-white text-gray-700 border border-gray-100"
                )}>
                  {msg.content}
                </div>
              </motion.div>
            ))}
            {isLoading && (
              <div className="flex gap-4 mr-auto">
                <div className="w-10 h-10 bg-white text-emerald-600 border border-emerald-100 rounded-xl flex items-center justify-center shrink-0 shadow-sm">
                  <Bot size={20} />
                </div>
                <div className="bg-white p-6 rounded-3xl border border-gray-100 flex items-center gap-3 shadow-sm">
                  <Loader2 size={20} className="animate-spin text-emerald-500" />
                  <span className="text-gray-400 font-bold text-sm uppercase tracking-widest">{t('thinking') || 'Thinking...'}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="px-4 pb-4">
        <div className="relative group">
          <input 
            type="text" 
            placeholder={t('type_message') || "Ask about allergies, food safety..."} 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend(input)}
            className="w-full pl-8 pr-20 py-6 bg-white border border-gray-100 rounded-[32px] focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all shadow-lg text-lg font-medium"
          />
          <button 
            onClick={() => handleSend(input)}
            disabled={!input.trim() || isLoading}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-4 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 transition-all shadow-lg shadow-emerald-100"
          >
            <Send size={24} />
          </button>
        </div>
      </div>
    </div>
  );
}
