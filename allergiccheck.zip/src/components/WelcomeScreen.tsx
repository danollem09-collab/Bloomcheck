import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, ArrowRight, Stethoscope, Eye, Activity, BookOpen } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from './LanguageSelector';

interface WelcomeScreenProps {
  onComplete: () => void;
}

export function WelcomeScreen({ onComplete }: WelcomeScreenProps) {
  const [isVisible, setIsVisible] = useState(true);
  const { t } = useTranslation();

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(onComplete, 500); // Wait for exit animation
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
        >
          {/* Background Image with Blur */}
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=2070" 
              alt="Medical Center"
              className="w-full h-full object-cover blur-sm scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-white/40 backdrop-blur-[2px]" />
          </div>

          <div className="absolute top-6 right-6 z-[110]">
            <LanguageSelector />
          </div>

          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            className="relative z-10 w-full max-w-2xl bg-white/95 backdrop-blur-md rounded-[40px] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.15)] border border-white p-10 md:p-12 flex flex-col items-center text-center"
          >
            {/* Logo Section */}
            <div className="flex flex-col items-center gap-2 mb-8">
              <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 border border-emerald-100 shadow-sm">
                <Shield size={36} />
              </div>
              <div className="space-y-0.5">
                <h2 className="text-xl font-black text-gray-900 tracking-tighter uppercase">{t('allergy_center')}</h2>
                <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-[0.2em]">{t('experts')}</p>
              </div>
            </div>

            {/* Title Section */}
            <div className="space-y-4 mb-10">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">{t('welcome')}</p>
              <h1 className="text-4xl md:text-5xl font-black text-[#2b6cb0] leading-[0.9] tracking-tight">
                {t('path_to_relief')}
              </h1>
              <p className="text-gray-500 font-medium max-w-md mx-auto leading-relaxed">
                {t('health_priority')}
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full mb-10">
              {[
                { icon: Stethoscope, label: t('consultation'), desc: t('consultation_desc') },
                { icon: Eye, label: t('symptom_checker'), desc: t('symptom_checker_desc') },
                { icon: Activity, label: t('allergy_testing'), desc: t('allergy_testing_desc') },
                { icon: BookOpen, label: t('resources'), desc: t('resources_desc') },
              ].map((item, i) => (
                <div key={i} className="flex flex-col items-center p-3 rounded-2xl bg-gray-50/50 border border-gray-100">
                  <item.icon size={20} className="text-[#2b6cb0] mb-2" />
                  <h3 className="text-[10px] font-bold text-gray-900 uppercase mb-1">{item.label}</h3>
                  <p className="text-[9px] text-gray-400 leading-tight">{item.desc}</p>
                </div>
              ))}
            </div>

            {/* Action Button */}
            <button
              onClick={handleDismiss}
              className="px-12 py-4 bg-[#2b6cb0] text-white font-black rounded-full flex items-center justify-center gap-3 shadow-2xl shadow-blue-100 hover:bg-[#2c5282] hover:scale-105 transition-all group uppercase tracking-wider text-sm"
            >
              {t('get_started')}
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Footer Links */}
            <div className="mt-8 flex items-center gap-4 text-[10px] font-bold text-gray-300 uppercase tracking-widest">
              <span>{t('about_us')}</span>
              <span className="w-1 h-1 bg-gray-200 rounded-full" />
              <span>{t('contact')}</span>
              <span className="w-1 h-1 bg-gray-200 rounded-full" />
              <span>{t('location')}</span>
              <span className="w-1 h-1 bg-gray-200 rounded-full" />
              <span>{t('privacy_policy')}</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
